package com.example.elements_imagination;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Table extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table);
    }
}