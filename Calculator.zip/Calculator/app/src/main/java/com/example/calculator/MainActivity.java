package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button button0;
    private Button button1;
    private Button button2;
    private Button button3;
    private Button button4;
    private Button button5;
    private Button button6;
    private Button button7;
    private Button button8;
    private Button button9;
    private Button button_ac;
    private Button button_delem;
    private Button button_multiply;
    private Button button_minus;
    private Button button_plus;
    private Button button_eq;
    private Button button_zap;
    private EditText input_text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        input_text = (EditText) findViewById(R.id.input_text);
        button0 = (Button) findViewById(R.id.button0);
        button1 = (Button) findViewById(R.id.button1);
        button2 = (Button) findViewById(R.id.button2);
        button3 = (Button) findViewById(R.id.button3);
        button4 = (Button) findViewById(R.id.button4);
        button5 = (Button) findViewById(R.id.button5);
        button6 = (Button) findViewById(R.id.button6);
        button7 = (Button) findViewById(R.id.button7);
        button8 = (Button) findViewById(R.id.button8);
        button9 = (Button) findViewById(R.id.button9);
        button_ac = (Button) findViewById(R.id.button_ac);
        button_eq = (Button) findViewById(R.id.button_eq);
        button_zap = (Button) findViewById(R.id.button_zap);
        button_plus = (Button) findViewById(R.id.button_plus);
        button_minus = (Button) findViewById(R.id.button_minus);
        button_multiply = (Button) findViewById(R.id.button_multiply);
        button_delem = (Button) findViewById(R.id.button_delem);




        button0.setOnClickListener(clickListener);
        button1.setOnClickListener(clickListener);
        button2.setOnClickListener(clickListener);
        button3.setOnClickListener(clickListener);
        button4.setOnClickListener(clickListener);
        button5.setOnClickListener(clickListener);
        button6.setOnClickListener(clickListener);
        button7.setOnClickListener(clickListener);
        button8.setOnClickListener(clickListener);
        button9.setOnClickListener(clickListener);
        button_ac.setOnClickListener(clickListener);
        button_eq.setOnClickListener(clickListener);
        button_plus.setOnClickListener(clickListener);
        button_zap.setOnClickListener(clickListener);
        button_minus.setOnClickListener(clickListener);
        button_multiply.setOnClickListener(clickListener);
        button_delem.setOnClickListener(clickListener);


    }
    View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (button0.isPressed()) {
                String s = input_text.getText().toString();
                s = s + button0.getText().toString();
                input_text.setText(s.toCharArray(),0, s.length());
            }

            if (button1.isPressed()) {
                String s = input_text.getText().toString();
                s = s + button1.getText().toString();
                input_text.setText(s.toCharArray(),0, s.length());
            }

            if (button2.isPressed()) {
                String s = input_text.getText().toString();
                s = s + button2.getText().toString();
                input_text.setText(s.toCharArray(),0, s.length());
            }

            if (button3.isPressed()) {
                String s = input_text.getText().toString();
                s = s + button3.getText().toString();
                input_text.setText(s.toCharArray(),0, s.length());
            }

            if (button4.isPressed()) {
                String s = input_text.getText().toString();
                s = s + button4.getText().toString();
                input_text.setText(s.toCharArray(),0, s.length());
            }

            if (button5.isPressed()) {
                String s = input_text.getText().toString();
                s = s + button5.getText().toString();
                input_text.setText(s.toCharArray(),0, s.length());
            }

            if (button6.isPressed()) {
                String s = input_text.getText().toString();
                s = s + button6.getText().toString();
                input_text.setText(s.toCharArray(),0, s.length());
            }

            if (button7.isPressed()) {
                String s = input_text.getText().toString();
                s = s + button7.getText().toString();
                input_text.setText(s.toCharArray(),0, s.length());
            }

            if (button8.isPressed()) {
                String s = input_text.getText().toString();
                s = s + button8.getText().toString();
                input_text.setText(s.toCharArray(),0, s.length());
            }

            if (button9.isPressed()) {
                String s = input_text.getText().toString();
                s = s + button9.getText().toString();
                input_text.setText(s.toCharArray(),0, s.length());
            }

            if (button_ac.isPressed()) {
                String s = input_text.getText().toString();
                s = "";
                input_text.setText(s.toCharArray(),0, s.length());
            }

            if (button_delem.isPressed()) {
                String s = input_text.getText().toString();
                s = s + button_delem.getText().toString();
                input_text.setText(s.toCharArray(),0, s.length());
            }

            if (button_eq.isPressed()) {
                String s = input_text.getText().toString();
                s = s + button_eq.getText().toString();
                input_text.setText(s.toCharArray(),0, s.length());
            }

            if (button_minus.isPressed()) {
                String s = input_text.getText().toString();
                s = s + button_minus.getText().toString();
                input_text.setText(s.toCharArray(),0, s.length());
            }

            if (button_plus.isPressed()) {
                String s = input_text.getText().toString();
                s = s + button_plus.getText().toString();
                input_text.setText(s.toCharArray(),0, s.length());
            }

            if (button_multiply.isPressed()) {
                String s = input_text.getText().toString();
                s = s + button_multiply.getText().toString();
                input_text.setText(s.toCharArray(),0, s.length());
            }

            if (button_zap.isPressed()) {
                String s = input_text.getText().toString();
                s = s + button_zap.getText().toString();
                input_text.setText(s.toCharArray(),0, s.length());
            }

        }
    };
}