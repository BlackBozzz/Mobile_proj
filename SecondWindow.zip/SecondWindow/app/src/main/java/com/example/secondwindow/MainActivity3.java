package com.example.secondwindow;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
    }
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnActFour:
                Intent intent = new Intent(this, MainActivity4.class);
                startActivity(intent);
                break;
            default:
                break;
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mymenu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    // обработка нажатий
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // TODO Auto-generated method stub
        if (item.getItemId() == R.id.first) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        } else if (item.getItemId() == R.id.second) {
            Intent intent = new Intent(this, MainActivity2.class);
            startActivity(intent);
        } else if (item.getItemId() == R.id.third) {
            Intent intent = new Intent(this, MainActivity3.class);
            startActivity(intent);
        } else if (item.getItemId() == R.id.fourth) {
            Intent intent = new Intent(this, MainActivity4.class);
            startActivity(intent);
        }

        return super.onOptionsItemSelected(item);
    }
}