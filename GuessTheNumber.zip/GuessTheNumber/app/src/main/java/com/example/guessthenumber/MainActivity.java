package com.example.guessthenumber;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView textView;
    EditText editText;
    Button button;
    int number;
    int level;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        editText = findViewById(R.id.editTextNumber);
        button = findViewById(R.id.button);
        level = 1;
        number = (int) (Math.random() * (100 * level) + 1);
        editText.setHint(getText(R.string.guess) + " " + String.valueOf(100 * level) +" )");


    }

    protected void Restart() {
        number = (int) (Math.random() * (100 * level) + 1);
        editText.setHint(getText(R.string.guess) + " " + String.valueOf(100 * level) +" )");
        textView.setText(getText(R.string.guess_welcome));

    }

    public void onClick(View v) {

        try {
            int guess_numb = Integer.parseInt(editText.getText().toString());

            if (guess_numb > (100 * level) || guess_numb < 1) {
                textView.setText("Число не из заданного диапазона");
            } else if (guess_numb > number) {
                textView.setText("Меньше");
            } else if (guess_numb == number) {
                textView.setText("Ураааа! Вы угадали)");
            } else if (guess_numb < number) {
                textView.setText("Больше");
            }
        } catch (Exception e) {
            textView.setText("Похоже, Вы не ввели число");
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mymenu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    // обработка нажатий
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // TODO Auto-generated method stub
        if (item.getItemId() == R.id.menu_exit) {
            System.exit(1);
        } else if (item.getItemId() == R.id.menu_easy) {
            level = 1;
            Restart();
        } else if (item.getItemId() == R.id.menu_normal) {
            level = 2;
            Restart();
        } else if (item.getItemId() == R.id.menu_hard) {
            level = 3;
            Restart();
        } else if (item.getItemId() == R.id.menu_restart) {
            Restart();
        }

        return super.onOptionsItemSelected(item);
    }


}